import { InjectionToken } from '@angular/core';

export const BEFORE_UNLOAD_MESSAGE = new InjectionToken('BEFORE_UNLOAD_MESSAGE');
export const BEFORE_UNLOAD_FN = new InjectionToken('BEFORE_UNLOAD_FN');
